#include "its/divine/legacy/system/system.hh"

#ifndef DOXYGEN_PROCESSING
using namespace divine;
#endif //DOXYGEN_PROCESSING

const ERR_type_t system_t::ERR_TYPE_SYSTEM=100;
const ERR_id_t system_t::ERR_FILE_NOT_OPEN=65134;




