#ifdef _DEB_HH_
 #undef _DEB_HH_
#endif
#ifdef DEB
 #undef DEB
#endif
#ifdef DEBEVAL
 #undef DEBEVAL
#endif
#ifdef DEBFUNC
 #undef DEBFUNC
#endif
#ifdef DEBCHECK
 #undef DEBCHECK
#endif
#ifdef DEBAUX
 #undef DEBAUX
#endif

